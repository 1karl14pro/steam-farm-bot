# Скрипт для быстрого деплоя на VDS
# Использование: .\deploy.ps1

# НАСТРОЙКИ - ИЗМЕНИТЕ НА СВОИ
$VDS_IP = "81.17.154.12"
$VDS_USER = "root"
$VDS_PATH = "/opt/steam-farm-bot"

Write-Host "[*] Начинаю деплой на VDS..." -ForegroundColor Green

# Создаем архив
Write-Host "[*] Создание архива..." -ForegroundColor Yellow
tar -czf steam-farm-bot.tar.gz --exclude=node_modules --exclude=.git --exclude=logs --exclude=*.log .

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Ошибка создания архива" -ForegroundColor Red
    exit 1
}

# Загружаем на VDS
Write-Host "[*] Загрузка на VDS..." -ForegroundColor Yellow
scp steam-farm-bot.tar.gz "${VDS_USER}@${VDS_IP}:/root/"

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Ошибка загрузки на VDS" -ForegroundColor Red
    exit 1
}

# Деплой на VDS
Write-Host "[*] Деплой на VDS..." -ForegroundColor Yellow
ssh "${VDS_USER}@${VDS_IP}" @"
cd $VDS_PATH
docker-compose down
tar -xzf ~/steam-farm-bot.tar.gz
docker-compose up -d --build
echo '[OK] Деплой завершен!'
docker-compose logs --tail=20
"@

if ($LASTEXITCODE -eq 0) {
    Write-Host "[OK] Деплой успешно завершен!" -ForegroundColor Green
} else {
    Write-Host "[ERROR] Ошибка деплоя" -ForegroundColor Red
    exit 1
}

# Удаляем локальный архив
Remove-Item steam-farm-bot.tar.gz -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "[*] Статус контейнера:" -ForegroundColor Cyan
ssh "${VDS_USER}@${VDS_IP}" "cd $VDS_PATH && docker ps | grep steam-farm-bot"

